title: Linux运行Linux命令及获取帮助
date: '2019-08-22 18:15:51'
updated: '2019-08-22 20:48:37'
tags: [Linux系列]
permalink: /articles/2019/08/22/1566468951373.html
---
# ﻿2.1、Linux(UNIX)的命令格式
```
命令 【选项】 【参数】 （command [options] [arguments]）
```
命令行中的每一项之间使用一个或多个空格分隔开，以方括号括起来的部分是可选的，即可有可元的。在命令行中每一部分的具体含义如下：
**命令**：告诉Linux操作系统做（执行）什么。
**选项**：说明命令的运行方式（可以改变命令的功能），选项部分是以“-”字符开始的
**参数**：说明命令影响（操作）的是什么（如一个文件，一个目录或一段正文文字）。
# 2.2、whoami
>命令：**whoami**
查看当前用户。
![image.png](https://img.hacpai.com/file/2019/08/image-97934bd1.png)



>命令:**who am i**命令
查看当前用户 肯显示该用户所在终端以及当前日期和时间，还有所使用计算机的IP地址
![image.png](https://img.hacpai.com/file/2019/08/image-e747daf9.png)

# 2.3、who命令 w命令
>命令： **who**
查看当前系统运行的用户。
![image.png](https://img.hacpai.com/file/2019/08/image-65fbaf6b.png)


>命令：**w**
如图所示：
![image.png](https://img.hacpai.com/file/2019/08/image-a485f138.png)

首先解释第一行从左到右的的每一项含义：
当前的时间是下午8：26：29秒
系统已经启动（up）了12分钟
目前有3个用户。
系统在过去1分内提交了0.00个任务
系统在过去10分钟内提交了0.03个任务* 
系统在过去15分钟内提交了0.05个任务
（Load average为平均负载，之 后的3 个数字分别表示过去1分内的负载、过去10分钟的负载和过去15分钟的负载）。
下面解释第3行：
其中前3列与who am i命令相同，不再解释
第4列(LOGIN@)表示dog用户于8点25分登录系统
第5列（IDLE）表示用户不是一个正在活动的用户，已经空闲了5秒钟，如果是0.00的话表示此用户不是一个空闲的帐户，此帐户正在活动。
第6列（JCPU）表示dog用户到目前为止一共使用了0.02秒的CPU时间
第7列（PCPU）表示dog用户当前所运行的程序使用了0.01s的CPU时间
第8列（WHAT）表示dog用户目前所使用的程序。是W

# 2.4、uname命令及带有选项
>命令：uname
显示所用操作系统，显示所用Linux
![image.png](https://img.hacpai.com/file/2019/08/image-e59f21e8.png)


>命令：uname -n
显示系统主机名
![image.png](https://img.hacpai.com/file/2019/08/image-819a1360.png)


>命令：uname -i
显示所使用系统的硬件平台名
![image.png](https://img.hacpai.com/file/2019/08/image-4238f558.png)


>命令：uname -n -i 或 uname -i -n 或 uname -in 或 uname -ni 都是一样的结果如图：
![image.png](https://img.hacpai.com/file/2019/08/image-a31f47c8.png)

也就是说命令的显示结果与选项的先后顺序无关，即无论两个选项怎么组合最终结果都相同。

>下面再介绍几个可能会用到的选项。
-r:：显示操作系统发布的版本信息
-s：显示操作系统名
-m：显示机器硬件名
-p：显示中央处理器的类型。
-a：显示所有信息。

>命令：--help 
![image.png](https://img.hacpai.com/file/2019/08/image-ff1f5192.png)

显示结果列出了uname命令的所有选项及简单介绍。


# 2.5、date、cal、和clear命令及带有参数命令
>命令：date
![image.png](https://img.hacpai.com/file/2019/08/image-2761c2ad.png)

显示系统当前日期时间。

>命令：cal(calendar
![image.png](https://img.hacpai.com/file/2019/08/image-b53402f2.png)

显示当前月份日历。


>命令：cal 8 2008![](https://upload-images.jianshu.io/upload_images/10034856-3668f3f8b6d717a8.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
第一个参数8为要显示的月份
第二个参数2008为要显示的年份

>命令：cal 2008
![image.png](https://img.hacpai.com/file/2019/08/image-9495a665.png)

显示一整年的月份


>命令：clear
此处不再贴图，清除终端窗口 的显示。
# 2.6、su和passwd命令

>命令：su(switch user)
命令：su - root
切换用户身份，当前如果是dog，输入以上命令，会提示输入root用户密码，密码正确变更为root用户，如图：![image.png](https://img.hacpai.com/file/2019/08/image-420e9f49.png)
该命令不但可以从普通用户切换到root用户，还可以从普通用户切换普通用户。
命令：exit
如果用户想从root切换回dog用户，输入以上命令（前提是从dog用户切换到root用户的），就会切换回dog用户。如图：
![image.png](https://img.hacpai.com/file/2019/08/image-240f5d2e.png)

如果用户从未变换过身份输入exit的话，那默认会退出帐号，到重新登录界面，如果是xshell的终端的话，终端则会断开。
指点迷津：在操作系统（或数据库系统）的管理维护中，有一个系统管理员应该奉行的金科玉律，即最小化远则，该原则是在能够完成工作的情况下尽量使用权限最低的用户。
**从root身份切换到普通身份，系统不会提示输入密码。**

>命令：passwd
1.以普通用户身份修改普通用户自身密码
![image.png](https://img.hacpai.com/file/2019/08/image-37638565.png)
上方第一张图中可以看到，要先写当前此用户密码才能输入新密码，而且新密码不能和旧密码相似。不然后提示无效密码。
第二图可以看到，普通用户是无法指定修改其它用户密码的。

2.以root身份修改密码。
>命令：passwd dog
![image.png](https://img.hacpai.com/file/2019/08/image-7fa5c091.png)

如上图可以看到root用户修改其它用户密码，无论密码是否是简单，都可以修改成功。
修改root密码。
![image.png](https://img.hacpai.com/file/2019/08/image-983effc7.png)
root用户修改root密码是不会让输入当前密码的。而且无论提示什么都是可以修改成功的。所以看到了root用户权限的强大。在以后的生产环境中，root用户是不会随便让其它人知道的。

>命令：passwd -S dog
![image.png](https://img.hacpai.com/file/2019/08/image-169b6705.png)
-s 查看当前用户密码状态。如上图显示 选项的大小写是区分的。 -s显示未知选项。而-S是成功的。
可以看到显示dog用户密码已设置，并且使用SHA512算法加密。
为了验证密码为空时的状态，我这里新建一个用户cat，不设置密码。
![image.png](https://img.hacpai.com/file/2019/08/image-1d57427a.png)
可以看到显示密码已被锁定，因为我创建此用户时未设置密码，可以可以用 passwd来指定修改cat用户的密码。如图：
![image.png](https://img.hacpai.com/file/2019/08/image-d9488778.png)
重新查看状态。
![image.png](https://img.hacpai.com/file/2019/08/image-e67e9609.png)

指点迷津：linux与UNIX的设置理念与微软完全不同，微软假设用户是傻子，所以微软的系统用户做尽可能多的事情，而linux和UNIX假设用户是猴子，用户做什么自己应该清楚。这可能也是Linux高效和稳定的原因。

passwd --status 选项同 passwd -S 命令
注意，如果写整个单词，前面应该加两-。只有ROOT有权限查看其它用户密码状态，普通用户是不能查看其它用户的。如图：![](https://upload-images.jianshu.io/upload_images/10034856-1094e7074a9a01a4.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
# 2.7 whatis命令与命令的--help选项
>命令：whatis命令
命令：whatis uname
如果你想获取uname命令是干什么的，那您就直接输入以上命令如图：
![image.png](https://img.hacpai.com/file/2019/08/image-cf3391e2.png)
可以看到显示为列出系统的信息。
命令：whatis who，显示谁登录了系统。
![image.png](https://img.hacpai.com/file/2019/08/image-17c5a9e6.png)


>命令：--help命令
该命令可用于linux的绝大多数命令，但不是所有命令，该选项显示命令的简要说明及选项列表。
命令：uname --help 如图： 显示 uname的help
![image.png](https://img.hacpai.com/file/2019/08/image-9dce7a6a.png)


# 2.8、 怎样阅读命令的使用摘要
当获得一个命令之后，其实不只是命令的--help选项，还有man命令和其它的一些说明文件都会产生命令的使用摘要。
>命令：date --help 因显示结果太长，只截取部分
![image.png](https://img.hacpai.com/file/2019/08/image-9544ea06.png)

命令：man date
![image.png](https://img.hacpai.com/file/2019/08/image-624d97f6.png)

两个命令是一样的结果，只不过我系统是中文，而man出来的是原版英文说明。
[]括号中的参数为可有可无。
a|b|c这种为只能使用三个中的一个。
<>括号中的参数为变量 ，即这个选项或参数是可以改变的。
# 2.9、利用man命令来获取帮助信息。
本节将介绍如何使用man命令来获取命令的使用说明。Linux命令的Man pages是又一种获取命令语法的帮助来源。在Linux中每一个命令都有对应的说明文件，而这些说明文件就叫做Man pages，Man pages中有像书一样的结构，其内容分为不同章节。
man命令的模式如下
man [<option|number>] <command | filename>
其中option是要显示的关键字，number是要显示的章节号，command是要了解的命令，filename为文件名。
>命令：man su
![image.png](https://img.hacpai.com/file/2019/08/image-ef45e5c3.png)
部分截取。

>命令：man -k who
如果想用一个命令，只记得大概前几个字符，比如  whoami命令，我只记得有一个who，那么就可以这输入以上指令。如图
![image.png](https://img.hacpai.com/file/2019/08/image-df0f2b36.png)
如图，就是搜索出来有关who的命令。
在这里提一下 man -f <command> 与 whatis 命令是相同的。


# 这一章应该了解的有
1.Linux(UNIX)命令的语法。
2.怎样确认登录所使用的用户(whoami)。
3.怎样发现在系统上工作的所有用户信息（who、w、users、tty）
4.怎样获取系统本身的信息（uname）
5.怎样获取日期和时间的信息(date 、cal)
6.怎样在不同的用户之间切换（su）
7.怎么更改用户的密码和获取 用户密码的状态（使用passwd命令）
8.怎样显示所查询命令的简单说明(使用whatis命令)
9.怎么使用--help选项来显示命令的简要说明和选项列表。
