title: 教你查看连接到手机热点设备的IP。
date: '2019-08-22 19:06:44'
updated: '2019-08-22 19:12:45'
tags: [安卓, 移动端自动化]
permalink: /articles/2019/08/22/1566472004034.html
---
﻿
# 一、下载终端命令行。
![自行百度下载哈](https://upload-images.jianshu.io/upload_images/10034856-39bcd93f87e7e634.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

# 二、在手机安装并打开终端命令行，输入ip neigh。
![此处为PC电脑无线网上及获取到的IP。](https://upload-images.jianshu.io/upload_images/10034856-647c465951963fed.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)![手机打命令后也可以看到](https://upload-images.jianshu.io/upload_images/10034856-53b6aa914c10a7de.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
##大家可以对比看一下，是一样的，此命令可以看到设备的IP。









---------
积极迎接各种挑战，才会使自己更加强大。
转载请注明出处，谢谢!
欢迎一起交流，学习。
![](https://upload-images.jianshu.io/upload_images/10034856-e33bec6160902486.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
