title: java--windows文件操作
date: '2019-08-22 19:17:41'
updated: '2019-08-22 19:26:12'
tags: [java]
permalink: /articles/2019/08/22/1566472661081.html
---
# ﻿1.文本的替换


```
  //file 文件  oldstr 要替换的文件   newStr新文本。  
  public static boolean modifyFileContent(File file, String oldstr, String newStr) {
        List<String> list = null;
        try {
            list = FileUtils.readLines(file, "UTF-8");
            for (int i = 0; i < list.size(); i++) {
                String temp = list.get(i).replaceAll(oldstr, newStr);
                list.remove(i);
                list.add(i, temp);
            }
            FileUtils.writeLines(file, "UTF-8", list, false);
        } catch (IOException e){
            //e.printStackTrace();
        }
        return true;
    }
```
# 2.文本中匹配正则
```
//path文本路径，pattern1正则。
   public static String pipeitxt(File path,String pattern1) { 
    	String a="";
        try {
            Pattern pattern = Pattern.compile(pattern1, Pattern.CASE_INSENSITIVE); // 要匹配的字段内容，正则表达式
            Matcher matcher = pattern.matcher("");
           // List<String> lines = Files.readAllLines(Paths.get("F:\\lesson_1.xml")); // 读取文本文件
            List<String> lines = FileUtils.readLines(path, "UTF-8");
            for (int i = 0; i < lines.size(); i++) {
                matcher.reset(lines.get(i));
                if (matcher.find()) { // 匹配正则表达式
                	//System.out.println(matcher.group(1));
                	a=matcher.group(1);
                	break;
                  //  lines.remove(i);
                    //lines.add(i, "test_str=HELLO WORLD!");
                }
            }
            //Files.write(Paths.get("F:\\lesson_1.xml"), lines);
            //FileUtils.writeLines(path, "UTF-8", lines, false);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return a;
    }
```
