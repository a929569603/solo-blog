title: 教你查看连接到手机热点设备的IP。
date: '2019-09-07 17:48:27'
updated: '2019-09-07 17:48:27'
tags: [安卓]
permalink: /articles/2019/09/07/1567849707822.html
---
﻿
# 一、下载终端命令行。
![image.png](https://img.hacpai.com/file/2019/09/image-01b335e0.png)


# 二、在手机安装并打开终端命令行，输入ip neigh。
(![image.png](https://img.hacpai.com/file/2019/09/image-66be087f.png)
![image.png](https://img.hacpai.com/file/2019/09/image-84b74d90.png)

# 大家可以对比看一下，是一样的，此命令可以看到设备的IP。
