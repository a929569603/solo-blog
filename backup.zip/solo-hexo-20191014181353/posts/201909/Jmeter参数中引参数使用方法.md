title: Jmeter参数中引参数使用方法
date: '2019-09-09 20:46:59'
updated: '2019-09-09 21:02:20'
tags: [jmeter]
permalink: /articles/2019/09/09/1568033219735.html
---
# 直接上图  参数1：mysql_id
>![image.png](https://img.hacpai.com/file/2019/09/image-5468c8e3.png)

# 第二个参数:num
>![image.png](https://img.hacpai.com/file/2019/09/image-f8858b0e.png)

# 请求中调用：两个下划线 ${___V(mysql_id_${num})}就能调用了。
>![image.png](https://img.hacpai.com/file/2019/09/image-edbe9187.png)

