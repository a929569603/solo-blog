title: java发送POST请求，请求数据为json格式
date: '2019-08-22 19:17:40'
updated: '2019-08-22 19:19:09'
tags: [java]
permalink: /articles/2019/08/22/1566472660499.html
---
﻿**项目中遇到传json数据的接口，总结一下吧。再遇到就能更快的进行测试了。后续集成到自动化测试接口软件中。** 
 [json相关jar包下载](https://u16518217.pipipan.com/fs/16518217-243422464)
[请求相关jar包下载](https://u16518217.pipipan.com/fs/16518217-243422440)
```
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

import net.sf.json.JSONObject;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicHeader;
import org.apache.http.protocol.HTTP;

public abstract class TestSend {

   // String URL = "url";

    public static void main(String[] args) {

        JSONObject jsobj1 = new JSONObject();
         jsobj1.put("key","value");
        
        
        //System.out.println(jsobj1);
        post(jsobj1,"url");//注册
    }

    public static String post(JSONObject json,String URL) {

        HttpClient client = new DefaultHttpClient();
        HttpPost post = new HttpPost(URL);
        post.setHeader("Content-Type", "application/json");
        post.addHeader("Authorization", "Basic YWRtaW46");
        String result = "";
        
        try {

            StringEntity s = new StringEntity(json.toString(), "utf-8");
            s.setContentEncoding(new BasicHeader(HTTP.CONTENT_TYPE,
                    "application/json"));
            post.setEntity(s);

            // 发送请求
            HttpResponse httpResponse = client.execute(post);

            // 获取响应输入流
            InputStream inStream = httpResponse.getEntity().getContent();
            BufferedReader reader = new BufferedReader(new InputStreamReader(
                    inStream, "utf-8"));
            StringBuilder strber = new StringBuilder();
            String line = null;
            while ((line = reader.readLine()) != null)
                strber.append(line + "\n");
            inStream.close();

            result = strber.toString();
            System.out.println(result);
            
            if (httpResponse.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                
                    System.out.println("请求服务器成功，做相应处理");
                
            } else {
                
                System.out.println("请求服务端失败");
                
            }
            

        } catch (Exception e) {
            System.out.println("请求异常");
            throw new RuntimeException(e);
        }

        return result;
    }

}
```

