title: selenium自带API总结
date: '2019-11-13 10:58:17'
updated: '2019-11-13 10:59:30'
tags: [selenium, web自动化]
permalink: /articles/2019/11/13/1573613897822.html
---
# **总结一下selenium自带的API。这一篇介绍webdriver相关的API。下篇总结driver元素定位相关及元素操作相关API。**
---
---
# webdevice相关
### 跳转页面。
```
self.driver.get('http://www.17mark.com')
```
### 浏览器前进后退
```
self.driver.forward()#前进
self.driver.back()#后退
```
### 隐式等待
```
self.driver.implicitly_wait(seconds)#当查找的元素没有找到时，将继续查找，直到达到超时时间。
```
### 窗口最大化
```
self.driver.maximize_window()
```
### 关闭当前窗口
```
self.driver.close()
```
### 退出驱动关关闭所有关联的窗口
```
self.driver.quit()
```
### 截图
```
self.driver.get_screenshot_as_file(Picture name path)#传入保存的图片地址及图片名称。
```
### 获取页面标题。
```
self.driver.title
```
### 获取当前所有窗口
```
self.driver.window_handles#获取当前所有窗口，返回列表。
```
### 切换窗口。
```
self.driver.switch_to_window(window[num]) #传入的是一个窗口句柄，配合上一个获取窗口使用。
```
### alert弹窗取消操作
```
alert= self.driver.switch_to_alert()
time.sleep(1)
alert.dismiss()
```
### alert弹窗确认操作
```
alert= self.driver.switch_to_alert()
time.sleep(1)
alert.accept()
```
### JS调用
```
self.driver.execute_script(js)
```
