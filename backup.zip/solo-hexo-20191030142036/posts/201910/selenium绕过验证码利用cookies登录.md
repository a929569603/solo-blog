title: selenium绕过验证码-利用cookies登录
date: '2019-10-12 18:03:48'
updated: '2019-10-12 18:08:15'
tags: [web自动化, selenium]
permalink: /articles/2019/10/12/1570874628057.html
---
今天醒来太早，洗漱收拾到公司8点半不到（公司9点半上班），干点什么呢，想到前几天朋友问我关于selenium元素定位的问题，来定位登录，想到这儿，我就想能不能像http请求那样利用cookies获取登录状态，这样就不用再进行登录了。说试就试。本篇文章就拿本网站17mark.com为例。

# webdriver提供的关于cookie的相关方法

```
get_cookies()     　　             获得cookie信息
add_cookie(cookie_dict)           添加cookie
delete_cookie(name)               删除特定的cookie
delete_all_cookies()              删除所有的cookie
```
# 实例
首先我已经登录了http://www.17mark.com 我刷新一下页面拿一下cookie信息。
![image.png](https://img.hacpai.com/file/2019/10/image-e387d620.png)
![image.png](https://img.hacpai.com/file/2019/10/image-dad78355.png)
可以看到request过去的cookies信息。

我们把cookies信息写一下，注意add_cookie(cookie_dict)方法接收的是一个字典。我们要写name和value。可以看一下。
![image.png](https://img.hacpai.com/file/2019/10/image-7857ad0d.png)
运行以上代码出现错误。
![image.png](https://img.hacpai.com/file/2019/10/image-1935100d.png)

unable to set cookie：
此问题是因为在driver在向浏览器添加cookie时，还未打开任何一个页面。
所以先打开页面后再添加cookie。 然后看我最终代码。

# 最终源码
```

driver = webdriver.Chrome()
#先打开一个页面。
driver.get('http://www.17mark.com')
#打开页面后再添加cookie。不然会报错。代码中的cookie信息已做删减。
driver.add_cookie({
    'name':'Hm_lvt_75c167c3d6bbdb54701bd69229764b15',
    'value':'1569208126,1569243807',
})
driver.add_cookie({
    'name':'Hm_lpvt_75c167c3d6bbdb54701bd69229764b15',
    'value':'1570842949',
})
driver.add_cookie({
    'name':'visited',
    'value':'%22%2Farticles%2F2019%2F09%2F24%2F1569325593532.html%22%5D',
})
driver.add_cookie({
    'name':'skin',
    'value':'nijigen',
})
driver.add_cookie({
    'name':'solo',
    'value':'34c7dae04126a90de56dded8f09c4ea7bc751032e6e101a5ac693d',
})
#添加cookies后再重新请求一次网站。
driver.get('http://www.17mark.com')
#此时已经为登录状态。
#再打印一下此次访问服务器返回的最新cookies。
print(driver.get_cookies())

```

# 注意
* 网站cookie好多都是动态的，每访问一次，更换一次。可以自行用get_cookies()方法获取最新cookies做参数化。
* cookie大多有过期时间，注意脚本运行时更新新cookie以免过期。
* 不是所有网站都把登录状态信息放在cookie中，有些网站关闭浏览器就会清除cookie，请自行判断，大部分是可以的。
