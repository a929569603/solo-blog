title: MQTT，SSL双向认证？jmeter插件如何连接。
date: '2019-12-02 18:37:59'
updated: '2019-12-02 18:54:50'
tags: [MQTT, jmeter]
permalink: /articles/2019/12/02/1575283079162.html
---
# 前几天公司同事遇到MQTT服务器用SSL双向认证连接方式，用jmeter插件不知道怎么连接。今天下午有时间研究了一下。
----
----
**同事提供了MQTT服务地址，和开发所使用的三个文件。**
![image.png](https://img.hacpai.com/file/2019/12/image-3cc09a18.png)
* [ ] apm.key
* [ ] ca.cer
* [ ] apm.cer

![image.png](https://img.hacpai.com/file/2019/12/image-05b25072.png)
### 我们看到插件所需要的是   **.jks**和 **.p12**类型的文件。
### 经过各种查。发现此插件官方说明都是用pem类型文件生成的。无果，，，，，.
---
---
---
# 官方文档是这样写的：

## Certification files for SSL/TLS connections

After deploying emqtt server, you get the following OOTB (out of the box) SSL/TLS certification files under ${EMQTTD_HOME}/etc/certs directory:

1. **cacert.pem** : the self-signed CA certification
    
2. **cert.pem** : certification for emqtt server
    
3. **client-cert.pem** : certfication for emqtt client in order to connect to server via SSL/TLS connection. In this jmeter plugin case, the client implies jmeter "virtual user"
    
4. **client-key.pem** **key.pem** : key files to protect client and server certification respectively
    

[Note:] The above server and client certifications are both issued by the self-signed CA. If you would like to use official certifications for your EMQTT deployment, please check out relevant document to configure it.

We will use the OOTB test certfications (as an example) to show you how to prepare the required certification files for this EMQTT JMeter plugin.

```
export PATH=$PATH:<YOUR_JDK_HOME>/bin

keytool -import -alias cacert -keystore emqtt.jks -file cacert.pem -storepass <YOUR_PASSWORD> -trustcacerts -noprompt
keytool -import -alias client -keystore emqtt.jks -file client-cert.pem -storepass <YOUR_PASSWORD>
keytool -import -alias server -keystore emqtt.jks -file cert.pem -storepass <YOUR_PASSWORD>

openssl pkcs12 -export -inkey client-key.pem -in client-cert.pem -out client.p12 -password pass:<YOUR_PASSWORD>
```
--------
--------
-------
----------
------------
-----------------


### 查了一下，keytool和openssl发现了点什么，照葫芦画瓢，然后这几个文件依次试吧。0V0!!!!!!
### 功夫不负有心人。被摸索出来了。 哈哈哈哈
keytool和openssl均在java_home/bin
```
keytool -import -alias client -keystore mqtt.jks -file ca.cer -storepass 123456
```
```
openssl pkcs12 -export -clcerts -in apm.cer  -inkey apm.key -out mqtt.p12

```

大家自己对应吧。第二条生成.p12的时候会提示输入密码。大家自行输入，然后填写到插件中的secret 如图，我设置的123456, 第一条的密码在最后一个参数也是123456。
