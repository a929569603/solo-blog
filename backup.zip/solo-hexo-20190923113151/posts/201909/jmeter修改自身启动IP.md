title: jmeter修改自身启动IP
date: '2019-09-09 19:51:56'
updated: '2019-09-09 19:52:55'
tags: [jmeter]
permalink: /articles/2019/09/09/1568029916314.html
---
# Jmeter修改自身启动IP
>分布式测试时，master机器有可能遇到多块网卡，然后IP会变为其它网段的IP，故而连接不上其它机器，或返回不了其它机器的执行结果。
这时个就应该修改一下Jmeter启动时使用的IP了。
在**jmeter.bat**中查找**set ARGS**这一句。
然后在其上边一行添加
**set rmi_host=-Djava.rmi.server.hostname=你要更改的IP**
然后在set ARGS这行最后加上空格%rmi_host%如图：
![image.png](https://img.hacpai.com/file/2019/09/image-56e7a7ed.png)
修改完毕，打开**jmeter-server.bat**查看IP是否变成你写的IP，如图：
![image.png](https://img.hacpai.com/file/2019/09/image-29dddf76.png)

