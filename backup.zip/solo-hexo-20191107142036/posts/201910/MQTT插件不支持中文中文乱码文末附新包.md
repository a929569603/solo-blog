title: MQTT插件不支持中文，中文乱码？（文末附新包）
date: '2019-10-14 09:36:49'
updated: '2019-10-14 09:36:49'
tags: [MQTT, jmeter]
permalink: /articles/2019/10/14/1571017009244.html
---
**某日，看到某群消息时，看到有人求助，因近期有接触过此插件，加上它一起看下。**
![image.png](https://img.hacpai.com/file/2019/10/image-26a7b96d.png)


# 过程（有很多，不一一列举了）
>![image.png](https://img.hacpai.com/file/2019/10/image-03b1cbea.png)
![image.png](https://img.hacpai.com/file/2019/10/image-29e6d631.png)

---
---

**中间各种方法都试了，还是不行，只能修改源码了。**

---
---

>![image.png](https://img.hacpai.com/file/2019/10/image-0aec4e7c.png)
![image.png](https://img.hacpai.com/file/2019/10/image-17237e46.png)
![image.png](https://img.hacpai.com/file/2019/10/image-f2398ef0.png)
![image.png](https://img.hacpai.com/file/2019/10/image-3f572e77.png)

---

最终获得了一波夸奖【笑哭】，主要以后有可能自己也会遇到。

# 支持中文的MQTT插件包。

[mqttxmeter1.14jarwithdependencies.jar](https://img.hacpai.com/file/2019/10/mqttxmeter1.14jarwithdependencies-b49d8f45.jar)

---
---
