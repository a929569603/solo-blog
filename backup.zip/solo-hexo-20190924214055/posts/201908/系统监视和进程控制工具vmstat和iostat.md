title: 系统监视和进程控制工具--vmstat和iostat
date: '2019-08-22 18:15:53'
updated: '2019-08-22 21:27:34'
tags: [Linux系列]
permalink: /articles/2019/08/22/1566468953339.html
---
# vmstat
用法：
```
vmstat [时间间隔] [显示的记录行数]
```
>![image.png](https://img.hacpai.com/file/2019/08/image-161d5a48.png)
命令解释：
1、_**process/r：** 进程正在等待CPU（运行队列的大小）
2、_**process/b：** 进程在不中断地睡眠
3、**swap/si：** 进程从交换区滚入（载入）内存。
4、**swap/so：**_进程滚出到交换区上，但是仍然处于运行状态。
5、**io/bi：** 载入内存的数据块数。
6、**io/bo：** 写入硬盘的数据块数。
7、**system/in：** 每秒钟的中断次数
8、**system/cs：** 每秒钟的环境切换次数。
9、**cpu/us：** 执行用户代码所使用的cpu时间。
10、**cpu/sy：** 执行系统码所使用的cpu时间。
11、**cpu/id：** CPU空闲时间。
12、**cpu/wa：** CPU等待时间。
当我们执行类似这种命令时，多覆盖一段时间的统计信息更有效，因为只拿一行的统计信息有问题我们可以理解为暂时的突跳（偶然事件），暂时不先不用管它。但是某一列或某几列的值在多行上都很高（持续在高位），这可能就是问题的所在。
# iostat
硬盘活动、硬盘等待队列的长度和硬盘热点（访问频率极高的硬盘区域）都是影响Linux系统整体效率的重要信息。
iostat命令语法
```

iostat [选项][时间间隔][刷新显示信息的次数]
```
命令选项解释
>-d-------显示硬盘所传输的数据和服务时间，即包括每个硬盘，d是disk的第1个字母。
-p-------包含每个分区的统计信息，p是partition的第1个字母。
-c-------只显示cpu的使用信息。
-x-------显示扩展的硬盘统计信息，x是extended的缩写。
![image.png](https://img.hacpai.com/file/2019/08/image-13228443.png)



>tps：表示transfers per second的缩写（每秒钟传输的数量）,一个transfer就是对设备的一个I/O请求。
MB_read/s:每秒钟从硬盘中读出数据的MB数。
MB_WRTN/S：每秒钟写入硬盘数据的MB数，wrtn为written的缩写。
MB_read:从硬盘中读出数据的总MB数。
MB_wrtn：写入硬盘数据的总MB数，wrtn为written的缩写。

