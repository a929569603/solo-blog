title: JMeter负载机配置
date: '2019-09-09 20:08:24'
updated: '2019-09-09 20:10:47'
tags: [jmeter]
permalink: /articles/2019/09/09/1568030904613.html
---
# 环境清单：
>首先我本机IP：192.168.1.57  控制端  master
负载机一：192.168.1.144       client端
负载机二：192.168.1.145       client端
# 一、修改本地文件
1.打开JMeter/bin目录下的**jmeter.properties**文件。
查找  **remote_hosts=**  修改为:


```
remote_hosts=192.168.1.144:1099,192.168.1.145:1099
```
如果需要让自己机器也负载的话把自己IP也加上localhost:1099  逗号隔开。
加上自己机器后，自己机器也要打开 jmeter-server.bat文件,目前你还不清楚此文件，请先看下边。
```
查找 server_port=1099修改：

#server_port=1099  查找到是这样  把前面#与去掉。

查找 server.rmi.localport= 修改为：

server.rmi.localport=1099    前面有#号的去掉#号 端口写1099
```
# 二、负载机需要的设置。
1.把刚才在 master机器上配置好的JMeter打包粘贴到其它两台服务器上，192.168.1.144\145。
这里说明一下，这样的话保证所有机器JMeter版本一致。
2.两台client端打开JMeter/bin/**jmeter-server.bat**文件，必须打开。如图：(这个图是是我master机器的。大家不要有误会。。。)
![image.png](https://img.hacpai.com/file/2019/09/image-f3a2b385.png)

这里大家必须检查一下图往上指的位置的IP和端口号,是不是你client端的IP及端口号1099。如若不是请检查，你虚拟机网卡是否开着。请把虚拟机网卡先禁用掉。只留你要用的网卡的。其实不关掉也可以，网上有其它方法让他指向你真正的IP，自行百度吧，哈哈。 这里大家就先禁掉就好。
关掉负载机防火墙。或添加白名单。
3.回到master机器打开JMemte，如图
![image.png](https://img.hacpai.com/file/2019/09/image-d46b26e2.png)

可以单个启动，也可以全部启动。


好了就到这里了。



----
如有错误请留言指正。
