title: Linux-输入-输出和管道（-）及相关的命令
date: '2019-08-22 18:15:53'
updated: '2019-08-22 19:00:40'
tags: [Linux系列]
permalink: /articles/2019/08/22/1566468953744.html
---
﻿在系统默认情况下，shell从键盘读（接收）命令的输入，并将命令的输出显示（写）到屏幕上。shell的标准命令输入是Standard Input，标准输出（Standard Output）。
可以在命令行中或shell脚本中指示shell将命令的输入或输出重定向到文件。输入重定向强迫命令从文件中读输入而不是从键盘。输出重定向将命令的输出送以一个文件而不是送到屏幕。当命令产生错误信息时，这些错误信息将被送到标准错误（显示），通常错误信息被送到终端的屏幕上。
# 6.1文件描述符与标准输入/输出
shell创建的每一个进程都要与文件描述符打交道。其实文件描述符就是Linux系统内部使用的文件代号。文件描述符决定从哪里读入命令所需的输入和将命令产生的输出及错误显示送到什么地方。
以下是文件描述符的进一步解释，其中，0、1和2为文件描述符的号码。
>0：标准的命令输入，文件描述的缩写为stdin。
1：标准的命令输出，文件描述的缩写为stdout。
2：标准的命令错误（信息），文件描述的缩写为stderr。
所有处理文件内容的命令都是从标准输入读入数据并将输出结果写到标准输出。可能会有读者问，你怎么知道文件描述符号和它们的缩写之间的对应关系？其实方法很简单，举个例子。如图：![](https://upload-images.jianshu.io/upload_images/10034856-73b2813f1e361502.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)一个简单的ls命令就获取了如此重要的信息，显示结果中每行的fd是file descriptor(文件描述符)的缩写。
![](https://upload-images.jianshu.io/upload_images/10034856-237e7512c11d2e8c.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)如上图输出到屏幕就是标准的输出。
![](https://upload-images.jianshu.io/upload_images/10034856-fb6ffda5a732da37.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)如上图错误信息，就是标准错误信息。

读者应该了解什么是标准输出和什么是标准错误信息了吧。
# 6.2使用find命令搜索文件和目录
可以使用find命令的层次结构中定位（找到）文件和目录。find命令可以使用诸如文件名、文件大小、文件属主、修改时间和类型的条件进行搜寻。find命令在路径名列表中递归地向下遍历目录树以寻找与搜寻条件相匹配的文件。当find命令找到了那些与搜寻条件相匹配的文件时，系统将把满足条件的每一个文件显示在终端上。find命令的语法格式如下。
```
find pathnames expressions actions
```
>pathnames:搜寻起始的绝对路径或相对路径。
expressions：由一个或多个选项定义的搜寻条件。如果定义了多个选项，find命令将使用它们逻辑与（and）操作的结果，因此将列出所有满足全部条件的表达式。
actions：当文件被定位之后需要进行的操作。默认操作是将满足条件的所有路径打印在屏幕上。在find命令中，可以使用如下的条件表达式（expressions）。
-name 文件名：查找与指定文件名想匹配的文件。在文件名中可以使用通配符。但是它们要放在双引号之内（“”）
-size[+|-]n：查找大小（尺寸）大于+n，或小于-n，或正好等于n的文件。在默认情况下，n代表512字节大小的数据块的个数。
-atime[+|-]n：查找访问时间已经超过+n天，低于-n天，或正好等于n天之前的文件。
-user loginID:查找属于loginID（用户）名的所有文件。
-type：查找某一类型的文件，如f(文件)或d(目录)。
-perm：查找所有具有某些特定的访问许可位的文件（以后将介绍）。
在find命令中，可以使用如下的动作表达式（actions）:
-exec 命令 {} \;：在每一个所定位的文件上运行指定的命令。大括号{}表明文件名将传给前面表达式所表示的命令。一个空格、一个反斜线（\）和一个分号（；）表示命令的结束。
-ok 命令 {} \;：在find命令对每个定位的文件执行命令之前需要确认。这实际上就是-exec命令的交互方式。
-print:指示find命令将当前的路径名打印在终端屏幕上，这也是默认方式。
-ls：显示当前路径名和相关的统计信息，如i节点（inode）数、以K字节为单位的大小（尺寸）、保护模式、硬连接和用户。
下面通过一些例子来进一步解释find命令的具体用法。
例一：![](https://upload-images.jianshu.io/upload_images/10034856-5494bff1c45092ea.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)find命令是从dog用户的家目录（也是当前用户）开始搜寻名为dog.wolf.baby的文件。
例二：![](https://upload-images.jianshu.io/upload_images/10034856-4d53665aa57a4762.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
可以看到如果想查找头为dog.尾为.baby的文件。上图三条命令都可以。即在通配符中加不加双引号都可行，查找到的结果也都相同。但是这里要注意一下，最好使用以上第一种命令进行搜索，因为这是标准的语法，其它的不保证在所有的UNIX或Linux系统上都能正常工作。

为以后面演示方便，我现在展示一下我的目录文件。![](https://upload-images.jianshu.io/upload_images/10034856-dba4bddda32f54e8.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
下面来看其它演示：
>例三：![](https://upload-images.jianshu.io/upload_images/10034856-41e1cccb19febda6.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)可以看到disable_dog.wolf.baby被删除了，所以现在理解-exec里说的{}的意思了吧，指的是前方搜索到的文件名。空格\;是结束。而且-exec没有提示信息。
例四：![](https://upload-images.jianshu.io/upload_images/10034856-54e6d2b44a86fef2.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
可以看到 -ok是有交互信息的。输入y   ，dog1.wolf.girl被删除了。

>例五：find . -mtime +3
查找修改时间大于3天的文件，也就是说三天之内我没有修改过的文件。
例六：find .-mtime -3
查找修改时间在3天之内的文件。
例七：find . -atime +3
查找访问时间大于3天的文件，也就是说三天之内我没有访问过的文件。
例八：find . -atime -3
也就是查找访问时间小于3天的文件。
例九：find ~ -size +20
搜索家目录下文件大小大于20个数据块的文件。
例十：find ~ -size -2
搜索家目录下文件大小小于2个数据块的文件。
# 6.3、将输出重定向到文件中
>默认情况下，如果同时产生了标准输出和标准错误信息。它们会同时显示在终端屏幕上。如图：
![](https://upload-images.jianshu.io/upload_images/10034856-782a16b32674db58.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)部分截图。
上图即有标准输出也有标准错误信息。如/etc/passwd是标准输出 /etc/pam.d/passwd也是标准输出。但是其它权限不够就是错误信息。他们同时输出到屏幕上了。看上去是不是眼晕。有没有方法不让他们显示到屏幕上。当然有此时，就用到了输出重定向。输出重定向的符号是：
**>：**覆盖原文件的内容
**>>：**在原文件之后追回内容
例1.![](https://upload-images.jianshu.io/upload_images/10034856-5beee31efb013089.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
我把ls -l的显示信息输出重定向到dog_wolf文件中，此命令运行完不会有提示。
例2：![](https://upload-images.jianshu.io/upload_images/10034856-ed1cd53af55c58da.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
例用>>符号重定向到dog_wolf2中，然后对比dog_worl和dog_worl2。发现是一样的东西 。这时候是不是产生疑惑，为什么两个是一样的呢。这是因为这两个文件刚开始都不存在，内容都为空，所以都是一样的了。
然后继续使用以下命令。![](https://upload-images.jianshu.io/upload_images/10034856-36bee4ef2745ca2c.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)是不是发现以前的东西没有了呢。
再继续实验。![](https://upload-images.jianshu.io/upload_images/10034856-0eaac5873f8c7c24.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)发现什么，追加到了最后，前面信息还在。所以发现区别了吧。>这个会覆盖之前的信息。而>>是输出重定向追加信息。
# 6.4重定向标准输出和标准错误信息
读者应该还记得在6.3中显示结果有错误信息也有正确信息吧。那能不能将正确信息，输出到文件中，将错误信息也输出到文件中呢。
>例1![](https://upload-images.jianshu.io/upload_images/10034856-851534b7e8adad32.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)上图看到没标准信息已经被重定向到output.std中了，6.1中讲过1代表标准命令输出。当然也可以把1去掉 看一下，因为也说过默认是标准输出。如图：![](https://upload-images.jianshu.io/upload_images/10034856-1714c7e64923d018.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

>好了相信大家已经知道如何将错误信息输出到文件中了。
例2：![](https://upload-images.jianshu.io/upload_images/10034856-a8a7a1df5f1decba.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
是不是验证了大家的想法呢。哈哈 酷吧。

>那现在有的同学可能会想能不能同时将两个信息输出到两个文件。当然可以啦。Linux只有你想不到没有它做不到，强大吧。
例3：![](https://upload-images.jianshu.io/upload_images/10034856-4759ef2f9529f71e.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)看到了吧。哈哈。强大不强大。

>那现在有同学想把错误信息和成功信息同时输出到文件中怎么办。看下面。
例4：![](https://upload-images.jianshu.io/upload_images/10034856-5f83de3b6233c8b9.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)下面解释一下这条命令。
由于passwd 默认是1所以是把标准输出，重定向到output_errs中，后面2>&1表示将2导出到1所指向的文件，也就是将标准错误信息也导出到1所指向的文件output_errs中。 强大吧。

>现在又有同学想能不能只使用一个>号就把所有信息全部重定向到一个文件呢，当然有。
例5：![](https://upload-images.jianshu.io/upload_images/10034856-67311d1e717080a5.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)看到命令没，这里的&符号代表了所有的文件描述符号（包括0、1、2）。所以&>output_err2就是将所有的信息都导出到output_errs2中。但这种方式不常用，因为使用&>表示法可能会在文件中包含一些不需要的信息。

# 6.5输入重定向及tr命令
重定向标准输入的符号是<号。Linux系统的一些命令只能使用标准输入，如tr命令。
>tr是translate的前两个字符。该命令的功能是转换、压缩/或删除来自标准输入的字符并将结果写到标准输出上。tr命令不接受文件名形式的参数，该命令要求它的输入被重定向为某个地方。下面通过一个例子来解释tr命令的输入重定向。![](https://upload-images.jianshu.io/upload_images/10034856-4c905afef8db1abe.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)上述功能将大写字母转变为小写字母。该命令的含义就是之前说的 tr的输入重定向到某个文件。并标准输出到屏幕。也可使用>重定向输出到文件中。如下图![](https://upload-images.jianshu.io/upload_images/10034856-e533806c3bf3e012.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

>tr命令的另一个用法是将DOS模式的正文文件（以回车符“\r”）和换行符（\n）结束一行)转换成Linux模式的文件（只用换行符\n来结束一行）。您可以使用带有-A选项的cat命令来显示一下dept.sata文件中的所有内容。![](https://upload-images.jianshu.io/upload_images/10034856-c685c5f11ddd12e8.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)可以看到确实是DOS结束符。现在可以使用tr命令r -d来删除dept.data文件中每行结束符中的\r符号并将结果存入dept.data.unix文件中。![](https://upload-images.jianshu.io/upload_images/10034856-35967db5fe80ef57.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
看下结果。



# 6.6、cut（剪切命令）
可以使用**cut命令从一个文件中剪切掉某些正文字段（fields,也就是列）并将它们到标准输出显示。实际上cut命令是一个文件维护的命令**其语法格式如下：
```
cut [选项]...[文件名]...
```
>其中的主要选项包括如下内容。
-f：说明(定义)字段（列）
-c：要剪切的字符。
-d：说明（定义）字段的分隔符（默认为Tab）
![](https://upload-images.jianshu.io/upload_images/10034856-be9ca42a5040973d.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
>例1：![](https://upload-images.jianshu.io/upload_images/10034856-4fc4e8095266f3c0.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)剪切第二列。显示在屏幕上，也可以重定向到文件中。这里不再做演示。此命令未使用-d这可以证明文件是以tab做分隔的。

>例2：![](https://upload-images.jianshu.io/upload_images/10034856-4d1264d1a5cbb593.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)可以看到此处分隔符为，号所以必须加-d选项。

>例3：![](https://upload-images.jianshu.io/upload_images/10034856-a155c74ae5970d7a.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
-c4-7表示从第4个字符一直取到第7个字符（总共4个字符）。

>指点迷津：
其实Linux系统的cut命令就相当于Windows系统的剪切操作，Windows系统的剪切操作是将剪切的内容放在了剪贴板上，而Linux系统的cut命令默认是将剪切的内容放在了标准输出上。只不过Linux系统的cut命令更强大，但是windows系统的剪切操作更简单。 还有一点是不同的剪切之后，文件中的内容是不会像Linux上那样消失的。

# 6.7、paste(粘贴)命令
该命令的语法模式如下：
```
paste [选项]...[文件名]...
```
>![](https://upload-images.jianshu.io/upload_images/10034856-562cc01e111aded8.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
![](https://upload-images.jianshu.io/upload_images/10034856-ea69e9e8d0812130.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

>下面将两个文件放合成一个文件。
![](https://upload-images.jianshu.io/upload_images/10034856-9fdcd8b5f29fea3a.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)如上图，默认以tab键分隔。
我们也可以用,号进行分隔。不过要加-d选项。如图。![](https://upload-images.jianshu.io/upload_images/10034856-7a2edbabd6025c39.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)


# 6.8、使用col命令将Tab转换成空格
>![](https://upload-images.jianshu.io/upload_images/10034856-512e3d2d8757b9b5.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)可以看到^号就是tab键的意思，![](https://upload-images.jianshu.io/upload_images/10034856-ade79124e862bc28.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)上图命令中 -x就是把tab键转换成对等的空格的意思。
col命令还有一些其他的特殊用途，但是目前我们所关心的只是这一功能而已。

# 6.9、使用sort命令进行排序。
>![](https://upload-images.jianshu.io/upload_images/10034856-3cb072e9b9820d67.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
显示结果告诉我们sort命令是按ASCII码的顺序对字符进行排序的，即小写字母在前大写字母在后。
接下来使用sort命令对test.sort文件进行反向(-r选项的功能)排序并忽略大小写(-F选项的功能)和去掉重复行(-u)选项的功能。如图：![](https://upload-images.jianshu.io/upload_images/10034856-74ee535892198b4f.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240) 

>![](https://upload-images.jianshu.io/upload_images/10034856-2fda75499e395943.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
![](https://upload-images.jianshu.io/upload_images/10034856-ced0b57ba2067960.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)上图中，-t: 是以:进行分隔，-k3是：号分隔后的第三列。可以看到1000 11都排在了1前面说明sort命令是以ASCII码排序的。再看下图![](https://upload-images.jianshu.io/upload_images/10034856-4001bc2c9ea5e52c.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)加-n后按数字进行排序了。

# 6.10、使用uniq命令去掉文件中相邻的重复行。
>-c：在显示的行前冠以该行出现的次数。
-d：只显示重复行。
-i：忽略字符的大小写。
-u：只显示唯一的行，即只出现一次的行。
>![](https://upload-images.jianshu.io/upload_images/10034856-b8e784debb9665a9.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)如上图可以看到已经去掉相邻重复的了。

>![](https://upload-images.jianshu.io/upload_images/10034856-6530ce983a37e54c.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)-c功能可以看到该字符出现了多少次。![](https://upload-images.jianshu.io/upload_images/10034856-b69b1bec47105ea2.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)-d只显示重复行。
![](https://upload-images.jianshu.io/upload_images/10034856-b6cb39852d276c17.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)-i 忽略大小写。![](https://upload-images.jianshu.io/upload_images/10034856-a298b6b00412dc07.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)-u只显示唯一的行。

# 6.11、管道（|）操作
命令格式如下：
```
命令1|命令2...
```
系统会将命令1的标准输出重定向为命令2的标准输入。可以在任何两个命令之间插入管道符。管道操作符之前的命令将把输出写到标准输出上。而管道后的命令将把这个标准输出当作它的标准输入来读入。
标准错误信息（stderr)并不通过管道传播，即第1个命令的错误信息不会传给第二个命令，当然第2个也不会。
>例1：利如你是管理员，想要知道目前有几个用户在登录着系统。
那么我们可以这样写
命令：**who | wc -l**![](https://upload-images.jianshu.io/upload_images/10034856-ea647428359944fc.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)神奇不神奇
如果想知道目前系统有多少用户包括未登录的。
命令:**cat /etc/passwd | wc -l**![](https://upload-images.jianshu.io/upload_images/10034856-d12c5763f7179dc3.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
另外想用 ls -l查看/etc下的文件，因太多一屏看不到，所以可以这样来
命令**ls -l /etc| more**![](https://upload-images.jianshu.io/upload_images/10034856-a3963de6464a4e30.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
除了以上介绍的管道功能外，还有一个xargs命令。
目前我的wolf文件夹有这些文件。![](https://upload-images.jianshu.io/upload_images/10034856-893f5a16a81a73c4.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
然后我想把这些带有 disable_前掇的给删除掉。
命令：![](https://upload-images.jianshu.io/upload_images/10034856-010c46930f617067.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
看到xargs的用法了没？。
# 6.12、使用tee命令分流输出。
>命令：**cut -f1 -d: /etc/passwd | tee passwd.cut | sort -r|tee passwd.sort | more**
解释：首先tee passwd.cut命令将由管道送过来的数据存入passwd.cut文件中，同时还通过管道将这些数据送给下一个命令进行处理（sort -r命令进行反向排序）。tee passwd.sort命令将由管道送过来的数据（反向排序后的用户名）存入passwd.sort文件，同时还通过管理将这些数据送给下一个命令进行处理（more命令进行分页显示。）
明白了吗？ 。分流输出。
# 6.13、您应该撑握的内容
>什么是标准输入/输出及标准错误信息？
文件描述符与标准输入/输出及标准错误信息的关系。
怎样利用find命令搜索文件和目录？
怎样在所定位的文件上运行指定的命令。（-exec(-ok) 命令 {} \;)
怎样将输出重定向到文件中？
重定向标准输出和标准错误
重定向符号>>和>的区别。
怎样将输入重定向？
tr命令的功能与用法。
cut(剪切)命令的用法。
paste（粘贴）命令的用法。
怎样使用sort命令排序？
怎样使用uniq命令去掉相邻的重复行？
怎样使用管道（|）将独立而简单的命令组合成更强的命令？
怎样使用tee命令分流输出？

欢迎一起交流，学习。
![](https://upload-images.jianshu.io/upload_images/10034856-e33bec6160902486.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
