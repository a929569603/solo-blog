title: ADB常用命令整理。
date: '2019-08-22 19:06:44'
updated: '2019-08-22 19:11:51'
tags: [adb, 安卓, 移动端自动化]
permalink: /articles/2019/08/22/1566472004578.html
---
﻿  最近项目中经常与安卓设备相连，用到adb命令。整理一下常用命令。

````
wifi控制命令
adb connect IP
若连接失败，可尝试插数据线运行以下两条命令后，方可拔掉数据线，在设备未关闭之前可以直接adb connect IP进行连接
adb tcpip 5555
adb connect IP
````
# 断开设备
```
adb disconnect IP
```
# 查看连接设备。
```
adb devices
```
# 多设备连接选择单个设备。
```
adb -s 设备名称。
```
>![多设备，-s选择一个设备操作。](https://upload-images.jianshu.io/upload_images/10034856-226f2f49272e3316.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
---
# 安装APK包命令
```
adb install 路径/包名.apk
```
---
# 卸载APP
```
adb  uninstall APP包名(com.xxxx.xxxx)。
```
---
# 查看APP版本号
```
adb shell "dumpsys package apk包名 | grep versionName"
```
---
# 录屏
```
adb shell screenrecord /sdcard/test.mp4
```
---
# 从PC电脑移动文件到手机端。下方命令把PC文件移动到/sdcard/根目录。
```
adb push PC文件 /sdcard/
```
---

# 从手机移动文件到电脑端.下方命令把 /sdcard/a.log文件移动到电脑D盘下。
```
adb pull /sdcard/a.log D:/
```
---
# 实时查看安卓日志。
```
adb logcat
```

---
# 导出安卓日志到PC

```
adb logcat -t 20000 -v threadtime *:V > D:1.log(PC路径log名称)
```
```
-t:导出系统最近20000条日志。不加-t默认导出从设备最近开机开始到现在的日志，不会主动关闭。加-t主动退出。
```
```
-v：设置输出格式， threadtime为可查看线程信息及日志输出时间。
```
```
过滤选项:
```
```
*:V : Verbose (明细);
```
```
*:D : Debug (调试);
```
```
*:I : Info (信息);
```
```
*:W : Warn (警告);
```
```
*:E : Error (错误);
```
```
*:F: Fatal (严重错误);
```
# # # # # # （注意：只能拿本次开机后的日志。）
---
# 打开APP
```
adb shell am start -n  APP包名（com.xxxx.xxx）/Activity名称。
```
---
# 清理APP缓存
```
adb shell pm clear 包名（com.xxx.xxx）
```
---
# ADB截图
```
adb shell screencap -p  路径图片名称（/sdcard/test.png）
```
---
# ADB修改安卓系统时间(root权限下,2019年7月16日10点10分10秒)
```
adb shell date -s "20190716.101010" 
```
---
# ADB设备内存查看
```
adb shell dumpsys meminfo
```
>![](https://upload-images.jianshu.io/upload_images/10034856-fd92fba68f1e53c9.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
# CMD连接adb shell后如何直接执行 adb shell后边的命令。重点是adb shell 后边用引号引起来。
```
adb shell  "ps | grep java"
```

