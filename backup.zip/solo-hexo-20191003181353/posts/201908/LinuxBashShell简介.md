title: Linux-Bash-Shell简介
date: '2019-08-22 18:15:50'
updated: '2019-08-22 18:48:40'
tags: [Linux系列]
permalink: /articles/2019/08/22/1566468950344.html
---
﻿在解释Bash shell之前，必须先介绍一下什么是shell。
读者应该都知道，计算机是不能识别是任何人类语言的，其中也名手英语。计算机只能识别由0和1组成的机器码，可是这些机器码对正常智商的人类来说实在太难记忆了，那么人怎样才能与计算机进行交流呢？就是使用命令解释器。，人输入类似英语的计算机命令到命令解释器，再由这个命令解释器将这些命令翻译成计算机的机器指令交由计算机执行。在Linux或UNIX操作系统上，这个命令解释器就叫shell。
# 5.1、shell的工作原理
其实当一个用户以命令行方式登录Linux或UNIX操作系统之后即进入了shell应用程序。使用xshell连接Linux系统登录系统之后，就会进入shell的控制，![](https://upload-images.jianshu.io/upload_images/10034856-63919509692377e2.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)其中[dog@localhost ~]$就是shell的提示符。从此时shell就随时恭候，等待您的差遣。并为您提供服务。

shell的功能是将用户输入的命令翻译成Linux内核(Kernel)能够理解的语言，这样Linux的内核才能真正的操作计算机的硬件。

可以将shell看成用户与Kernel之间的一个接口。shell主要是一个命令解释器，它接收并解释用户输入的命令，然后将他们传给Kernel。最后由Kernel来执行这些命令。

# 5.2、bash的成长历程
这里按书上顺序列举一下shell的名称。大家可以自行百度。这里不再细说。
>Bourn shell简称bsh  所有shell的始祖
C shell简称csh
Korn shell简称ksh
Z shell 简称zsh
TC shell 简称tcsh
Bourn-Again shell简称bash
这里可以查看一个自己系统中所有的shell
![](https://upload-images.jianshu.io/upload_images/10034856-101976f20b23efdf.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
可以看到我这里只有bash。
# 5.3、使用type识别bash的内置命令
Linux操作系统的命令分为两大类，一类是内部命令即内置在bash中的命令，另一类是外部命令（即该命令不是内置在bash中的）。
那么怎样才能知道哪些命令是内部命令，哪些命令是外部命令呢，答案是使用type命令。
>命令：man type![](https://upload-images.jianshu.io/upload_images/10034856-4b79af5558cd9a9f.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)以上部分为内部命令，是不是还不少呀。

>如果还想知道一些其它信息，就要用到type命令了
type [选项] 命令名
-t：显示文件的类型，其文件类型如下。file为外部命令；alias为别名；builtin为bash的内置命令。
-a：列出所有包含指定命令名的命令，也包括别名（alias）.
-P：显示完整的文件名（外部命令），或者为内部命令。
>这里不再一一演示，看图吧![](https://upload-images.jianshu.io/upload_images/10034856-fbfc8fc8c259e6a9.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
三个命令均显示内置命令。

>如何确定一个文件是可执行文件。还记得file命令吗？
**file /bin/pwd**![](https://upload-images.jianshu.io/upload_images/10034856-9a12748ce7e2c830.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
其实除了type 命令还有which 或 whiatis命令来获取命令的类型。
如图：![](https://upload-images.jianshu.io/upload_images/10034856-035a1f5f9f7792f1.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
可以看到这两个命令确实可以获取到一些信息，但不如type获取的信息丰富。

>来看一个外部命令。
**type -t whoami**![](https://upload-images.jianshu.io/upload_images/10034856-f6388b5bfdf3c7e9.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)可以看到file为外部命令。
# 5.4、利用通配符操作文件
>**为了演示，首先给大家看一下目录中的文件的名称。**![](https://upload-images.jianshu.io/upload_images/10034856-b842d45a339c3d4b.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

**首先介绍一下Linux操作系统中提供的通配符。**
>**\*：**将匹配0个(即空白)，或多个字符。
**?：**将匹配任何一个字符而且只能是一个字符。
**[a-z]：**将匹配字符a~z范围内的所有字符。
**[^a-z]：**将匹配所有字符但是a~z范围内的字符除外。
**[xyz]：**将匹配方括号中的任意一个字符。
**[^xyz]：**将匹配不包括方括号中的字符的所有字符。

下边开始举例。
>命令：ls **\*.wolf**
显示出结尾是wolf的文件。
![](https://upload-images.jianshu.io/upload_images/10034856-58c97f988eaacf38.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

>命令：**ls \*.wolf.\***
显示中间为wolf的文件。![](https://upload-images.jianshu.io/upload_images/10034856-94407cfd987bc00a.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

>命令：**ls dog?.wolf**
显示 前三个字符为dog第四个字符是任意字符，结尾是.wolf文件。![](https://upload-images.jianshu.io/upload_images/10034856-102190cc74063259.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

>命令:**ls dog??.wolf**
显示前三个字符为dog第四五个字符是任意字符，结尾是.wolf的文件。![](https://upload-images.jianshu.io/upload_images/10034856-81a6345391ebfcd9.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
为了后边演示方便，此处再次touch两个文件 dog1.wolf.girl  dog2.wolf.boy
>命令：**ls dog[1-2].\***
显示dog1.和dog2.开头的文件。![](https://upload-images.jianshu.io/upload_images/10034856-1a7c7f6adc8e6e92.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)


>命令：**ls dog[^1-2].\***
显示所有的不以dog1.和dog2.命名的文件。![](https://upload-images.jianshu.io/upload_images/10034856-d446d0afe2facace.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

>其实不只是在ls命令中可以使用通配符，在其他的Linux指令中同样也可以使用能通配符。如果想删除文件名以dog开始，之后跟两个数字随后跟一个"."开头的所有文件，就可以使用rm 通配符来删除了。
如图：![](https://upload-images.jianshu.io/upload_images/10034856-5f6174a78f0fcfca.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)删除成功dog11.wolf和dog21.wolf两个文件已经不存在了。
# 5.5、利用tab键补齐命令行。
如果Linux命令记不清了，只记得前面几个字符，该怎么办，不要急Linux设计者早就高瞻远瞩地想到了这一点，现在就用了键盘上的  tab键了。
>利如现在只记得whoami的命令的前四个字符。whoa然后按tab键，神奇不神奇。
不只是命令，也同样适用玩目录名称和文件名称等。这里不再多说。
# 5.6、命令行中~符号的使用
实际上~符号的使用在第3章的3.4节中就简单地介绍过，本节将更进一步地介绍~符号的用法，~符号的含义如下:
>(1)如果~符号后面没有用户名，则该符号代表当前用户的家目录。
(2)如果~符号后面跟一个用户名，则该符号代表该用户的家目录。

>命令**：~**
下面演示：![](https://upload-images.jianshu.io/upload_images/10034856-483a7561b2808864.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)![image.png](https://upload-images.jianshu.io/upload_images/10034856-60f7ba03a6264c78.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
可以看到这样可以访问到worf文件夹。

>命令**：~用户名**
![](https://upload-images.jianshu.io/upload_images/10034856-38fb011553db5025.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)可以看到权限不足，因为dog用户不能访问cat用记的家目录。所以咱们可以使用至高无上的root用户进行操作。![](https://upload-images.jianshu.io/upload_images/10034856-a42e69d852f2519f.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)可以看到显示出了cat目录下的dog文件夹。

# 5.7 history 命令与操作曾经使用过的命令。
绝大多数shell都会保留最近输入的命令的历史。这一机制可以使用户能够浏览、修改或重新执行，之前使用过的命令。使用history命令将列出用户最近输入过的命令（也包括您输入的错误命令）。

>命令**history**
![](https://upload-images.jianshu.io/upload_images/10034856-4a94bc6a15e8a975.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)在这里可以看到以前运行过的shell命令。
如果想要重新执行某个命令，比如第一条命令。那么可以这样执行。
>**!n**
执行编号为n的命令。比如**!65**![](https://upload-images.jianshu.io/upload_images/10034856-5db104ac6dc29652.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)是不是成功了呢。
接下来如果想把命令ls dog[1-2].*中的2改成3。怎么做。在执行完!65后，再执行\^2\^3，就成功了。看图：![](https://upload-images.jianshu.io/upload_images/10034856-e57d4d608d0eadc5.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
此符号看起来作用不大，但在网络测试中比ping IP时，用处就会很大。

>Linux还提供了更实用的更丰富的功能。
1.利用键盘上的上下箭头键在以前使用过的命令之间移动。
2\.按CTRL+R键在命令的历史记录中搜寻一个命令。当按住CTRL+R时，会出现以下提示信息。![](https://upload-images.jianshu.io/upload_images/10034856-b5cf753fbd6ce87e.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
比如我要搜索 tail -4 /etc/passwd命令。那我只需要写一个字符一个字符写 后面会出现历史记录中的命令。
如图流程：![输入一个t时，出现了以下命令。不是咱们想要的](https://upload-images.jianshu.io/upload_images/10034856-799b44576dcabb4d.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)![输入ta时出现如下命令不是我们想要的](https://upload-images.jianshu.io/upload_images/10034856-138e80695689ad19.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)![出现了吧。现在可以直接回车，执行，也可以左右键头键来进行编辑。](https://upload-images.jianshu.io/upload_images/10034856-801a196fb82fb078.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
假如不是咱们想要的。比如我想要**tail lists**,那就继续按CTRL+R，就会找下一个。方便吧。
还有一种。比如PING一个IP地址，可以一个点一个点打上去不太方便，可以在终端按住esc+.来查找以前ping过的IP。
不再演示。
Linux系统的历史功能强大吧？

# 5.8、bash变量简介及大括号{}的用法
shell变量就是内存中一个命了名的临时存储区。变量中所存储的信息有以下两种：
>1.按用户习惯定制shell所需的信息。
2.使一些进程正常工作所需的信息。
为了方便系统的管理和维护（也是为了系统的正常工作），Linux系统预定义了一些系统常用的变量。
这些变量用户可以直接使用。
比如说系统中存在PATH的预定义变量，在这个变量中存放着执行一个命令时要搜寻的路径，即如果一个命令存储在PATH所列出的任何一个路径中，用户就可以只输入命令名来运行这个命令，其中每一个路径用:号隔开。如图：![](https://upload-images.jianshu.io/upload_images/10034856-69f4cbb203409673.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

系统中还存在一个变量为$HOME变量，存放了当前用户的家目录。如图：![](https://upload-images.jianshu.io/upload_images/10034856-f940a60631b0d186.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)![](https://upload-images.jianshu.io/upload_images/10034856-ec826523fbf94978.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

初看起来，cd $HOME命令用处也不大，因为完全可以使用cd ~命令来完成同样的功能，其实不然，如果Linux(也可以是UNIX)上安装了Oracle数据库，要管理或维护Oracle系统的文件，此时使用cd ~命令就没有办法切换到Oracle的文件所在目录，因为Oracle的文件的安装目录是存在了一个叫ORACLE_HOME的变量中，此时就可以使用cd $ORACLE_HOME切换到Oracle的安装目录，是不是很方便？

>#  大括号的用法。
>比如我想 touch两个文件，baby.dog和baby.wolf,我可以如图来创建。
![](https://upload-images.jianshu.io/upload_images/10034856-06451f59ba03cb76.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
但是我也可以这么来创建。
touch baby.{dog,worf}
![](https://upload-images.jianshu.io/upload_images/10034856-25c32980e7baf953.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
是不是成功了。
假如我想创建 **girl.dog girl.wolf boy.dog和boy.wolf**
可以这样 touch {girl,boy}.{dog,wolf}
![](https://upload-images.jianshu.io/upload_images/10034856-6f46090778a9f7b7.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)方便吧。
其实不只是touch中可以这么用，其它命令中也可以这么用，比如rm
命令：rm baby.{dog,wolf}
![](https://upload-images.jianshu.io/upload_images/10034856-a1457149434445b5.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
成功。
# 5.9将一个命令的输出作为另一个命令的参数
因为UNIX的原则是每一个命令都很简单而且只完成单一的功能，因此想要完成比较复杂的工作时，可能就需要将一些命令组合在一起。例如，将一个命令的输出结果作为另一个命令的输入参数。

> 想要知道目前所使用的系统的主机名，可以使用如下命令:
命令：hostname![](https://upload-images.jianshu.io/upload_images/10034856-9ff29536c915d58f.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
那么我们输出自己的主机名
echo "This computer system's name is hostname"
![](https://upload-images.jianshu.io/upload_images/10034856-ecdee4b0192ad4fb.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)结果是让人失望的，因为显示的不是自己的主机名，而还是hostname.
再输入以下命令:**echo "This computer system's name is \`hostname\`"**![](https://upload-images.jianshu.io/upload_images/10034856-af034ea87d402028.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)是不是成功了呢。
其实两个反点号相当于**$(hostname)**
例如这样也是同样的。![](https://upload-images.jianshu.io/upload_images/10034856-f8969dfa2fc144a8.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
别看``和$()看上去挺简单的，但是还挺管用的。
# 5.10、使用Linux命令进行数学计算。
![](https://upload-images.jianshu.io/upload_images/10034856-7d744efbfe634c2f.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)首先在不定义变量的情况下是这样的这不是我们想要的。
>1.变量赋值
![](https://upload-images.jianshu.io/upload_images/10034856-ec8b085908176935.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)可以看到在定义赋值时，不要有空格。不然会出错。
现在成功了。
现在我想要求一下语文成绩和数学成绩的总和。![](https://upload-images.jianshu.io/upload_images/10034856-465a880fddb4cc58.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)注意有空格。不然是会出错的。
格式就是这个样子这里介绍一下其它的运算符：
>**\+ - * /  :**加减乘除（除是整除）
%号是取余。
假如yuwencj=2 ;  shuxuecj=3
**两个\*是次方符，前面一个数的后面一个数次方，比如 echo $[ $yuwencj**$shuxuecj ]的意思是2的3次方。![](https://upload-images.jianshu.io/upload_images/10034856-a1fecc2680ff5013.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
# 5.11命令行中反斜线（\）的用法。
>这里不讲太多 反斜线也叫逃逸符号。即\后的特殊字符逃脱其特殊含义而恢复原来的字面意思。
比如 $符号表示提取一个变量的值。如果要恢复此$符的意思比如美元意思 那我就要在前边加上\$反斜线。
# 5.12Linux命令中引号的用法。
![](https://upload-images.jianshu.io/upload_images/10034856-a2492794a2bd674e.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
首先用双引号和单引号输出都是同样的。那单引号和双引号有什么区别呢？
>(1)单引号('）禁止所有的命令行扩展功能
(2)双引号("):禁止所有的命令行扩展功能但以下特殊字符除外。
(3)美元符号($):
(4)倒引号(`):
(5)反斜线(\):
(6)叹号(!):

举例说明：
>例1：![](https://upload-images.jianshu.io/upload_images/10034856-30e288df85028224.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)例1说明，在price上边加双引号，结果还是显示6839说明双引号不能禁止$符号。
例2：![](https://upload-images.jianshu.io/upload_images/10034856-d94e72bb97822ae1.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)例2说明单引号可以禁止$符。
例3：![](https://upload-images.jianshu.io/upload_images/10034856-afc3a9c3df07d02e.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)例3说明单引号可以禁止倒引号（`)的功能。
例4：![](https://upload-images.jianshu.io/upload_images/10034856-085759bb5b5639bd.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
输出 \$MAIL ,上图第一个命令是因为反斜线是逃逸符号，它将恢复紧跟其后的$的原本意思为了显示\$MAIL,试着加了个引号，也不能输出想要的结果，说明引号不能禁止反斜线的功能。于是换成单引号，成功输出，说明单引号可以禁止反斜线的功能。
例5：![](https://upload-images.jianshu.io/upload_images/10034856-289b1c8dc16baa8f.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)假如我想输出!61，上图第一个命令，显示的是以前的命令，因为 ！61就是执行第61个历史命令。所以为了要显示！61这个字符串本身，试着加了个双引号，结果还是历史命令，说明双引号不能禁止叹号的功能，又试着加了个单引号，结果能输出！61了，说明单引号可以禁止！号的功能。

# 5.13您应该掌握的内容
>shell的工作原理
怎样知道系统中有哪些shells及目前所使用的shell?
了解常用的shell及bash的发展过程。
利用type命令识别Linux命令的类型。
bash中常用的通配符。
怎样在命令中灵活地使用通配符。
怎样使用Tab键命令行的补齐功能？
使用~符号进行目录的切换。
了解操作历史命令方法及如何利用快捷键来提高工作效率。
了解bash变量及大括号{}的用法。
如何在Linux命令中使用倒引号(`)?
怎样使用Linux命令和变量进行数学去算？
逃逸字符反斜线（\）的用法。
熟悉在Linux命令中单引号和双引号的用法。


-----
积极迎接各种挑战，才会使自己更加强大。

欢迎一起交流，学习。
![](https://upload-images.jianshu.io/upload_images/10034856-e33bec6160902486.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
