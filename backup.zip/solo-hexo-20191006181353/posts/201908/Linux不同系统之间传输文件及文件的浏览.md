title: Linux不同系统之间传输文件及文件的浏览
date: '2019-08-22 18:15:52'
updated: '2019-08-22 21:21:31'
tags: [Linux系列]
permalink: /articles/2019/08/22/1566468951932.html
---
# 4.1.ftp简介
ftp命令是使用标准的ftp协议在不同的系统之间传输文件，这些系统既可以是相似的，也可以是不相似的操作系统。在Oracle Linux系统上FTP服务的守护进程被称为"very secure FTP"(非常安全的FTP)，其守护进程为vsftpd.
>安装vsftpd服务。
**yum install vsftpd**
在使用ftp传输文件时，既可以利用正文模式也可以使用二进制模式。
ftp语法模式如下：
**tfp 主机名或IP地址**

>首先打开widonws的DOS界面，输入**f:**进入f盘，创建一个文件夹为**md ftp**，然后cd ftp。然后输入命令：**ftp linuxIP**整个过程如图所示。
![image.png](https://img.hacpai.com/file/2019/08/image-b939b0d8.png)
输入命令后，输入linux用户名dog，然后输入密码，就进入了ftp内。
这里连接时可能会出现连接超时，请确认系统安装了**xinetd**和**telnet-server**以及**telnet**。
未安装请安装。
**yum install xinetd
yum install telnet-server
yum install telnet**
将xinetd和telnet服务加入随系统启动
**systemctl enable xinetd
systemctl enable telnet.socket**  ///这里无所谓
安装完成之后，启动
**systemctl start xinetd
systemctl start telnet.socket**
在配置telnet server的机器上面运行**iptables -F**清楚所有防火墙规则，当然，只是测试的时候可以这样，在正式服务上面千万不要这样做，弄不好就酿成大祸，下课可不能怪我哦！
好了重新打开windows DOS界面，重新进行连接是不是OK了呢？。
# 4.2利用ftp将文件从本地传送到远程系统。
ftp有两种传送文件的模式，一种是传输纯文本的  ASCII模式，另一种是传输二进制文件的bin模式。
1.从本地发送纯文本文件(ascii模式)到远程Linux上。
>1.按4.1进行连接，连接上以后pwd看一下是不是dog的家目录。
![image.png](https://img.hacpai.com/file/2019/08/image-37f53875.png)
2\.输入**ascii** 切换到ascii模式。如图：
![image.png](https://img.hacpai.com/file/2019/08/image-a3958fd3.png)
3\.输入ls,显示一下目录中的文件。,此时有可能出现以下错误：如图:
![image.png](https://img.hacpai.com/file/2019/08/image-1fc090b2.png)
输入以下命令即可**quote PASV**
![image.png](https://img.hacpai.com/file/2019/08/image-7fbc4179.png)
成功了。
4.开使传输文件，命令：**put game.txt**。这时有可能再出现问题，
![image.png](https://img.hacpai.com/file/2019/08/image-1ba9de93.png)
这时呢回到Linux系统
使用命令**getsebool -a|grep ftp**
查看**ftp_home_dir ftpd_full_access 和ftpd_use_passive_mode是否为on**。
如果为 off 使用如下三条命令设置为on.
**setsebool ftpd_full_access on
setsebool ftpd_use_passive_mode on**
**setsebool ftp_home_dir on**
再次使用命令查看状态**getsebool -a|grep ftp**如图：
![image.png](https://img.hacpai.com/file/2019/08/image-daf9071d.png)

OK了吧，现在再从ftp进行连接。传输文件。
如图：
![image.png](https://img.hacpai.com/file/2019/08/image-d10b84b4.png)
成功了。回到远程服务器上看一下是否传送成功。
![image.png](https://img.hacpai.com/file/2019/08/image-53d5c0c1.png)
成功。

2.多文本文件传输。
>命令：**mput 文件1 文件2**
如图：
![image.png](https://img.hacpai.com/file/2019/08/image-8dfd0cf5.png)
如图，上传两个文件，会提示两次交互信息。我们可以关闭提示信息。不然上传多个文件每个都要输入y还不够麻烦的呢。
命令：prompt 
关闭交互。
![image.png](https://img.hacpai.com/file/2019/08/image-e1b38056.png)


3.传输二进制文件如图片。传输到远程服务器。
>1.切换模式，输入命令**bin**,切换成二进制模式。
2.传输所有的jpg文件到远程服务器,命令：**mput  \*.jpg**
![image.png](https://img.hacpai.com/file/2019/08/image-12f153b3.png)
如图，不再提示交互信息，传输成功。
![image.png](https://img.hacpai.com/file/2019/08/image-d1e79478.png)
# 4.3利用ftp将文件从远程系统传输到本地。
1.还是同上，两种模式，这边就不再写例子。
>ascii模式，首先切换到ascii。
命令：**get 文件**
输入以上命令，进行文件的传输。有可能再次遇到问题
![image.png](https://img.hacpai.com/file/2019/08/image-94d5fcfd.png)
再输入几条命令。
[root@dog ~]#  **setsebool allow_ftpd_use_nfs on**
[root@dog ~]#  **setsebool allow_ftpd_use_cifs on**
[root@dog ~]#  **setsebool allow_ftpd_anon_write on**
然后再重新 get 文件。
如图，成功。
![image.png](https://img.hacpai.com/file/2019/08/image-4bb7b192.png)


2.同时多个文件传输回本地。
>命令:**mget 文件1 文件2**
![image.png](https://img.hacpai.com/file/2019/08/image-d4eac6ef.png)


3.切换二进制模式。（此处不再做试范）
1.输入 **bin**。切换到二进制。
2.**mget \*.jpg**（注意扩展名区分大小写。）
![image.png](https://img.hacpai.com/file/2019/08/image-5ad40a7e.png)
如图。
![image.png](https://img.hacpai.com/file/2019/08/image-bae8c48c.png)


>指点迷津
注意：**不管是如何传输，假如当前目录下有此文件，再传输同名称的文件时，不会提示，直接覆盖。**
# 4.4、使用file命令确定文件中数据的类型。
在Linux或UNIX系统中查看一个文件之前，要先确定该文件中数据的类型，之后再使用相关命令或方法打开文件。
与微软系统不同，在Linux和UNIX系统中文件的扩展名（即后缀）并不代表文件的类型。也就是说扩展名与文件的类型没有关系。因此在打开一个文件之前就要确定该文件的类型，确定文件类型的命令是**file**。
>命令：看图
![image.png](https://img.hacpai.com/file/2019/08/image-42373aaf.png)
红框代表类型。 可以看到pwd是可执行文件类型。剑头指向地方也再一次验证了有特殊字符命名的文件，需要用引号引起来。


# 4.5使用cat命令浏览正文文件的内容。
cat [options] [files]
>命令 ：**cat 文件**
如图：
![image.png](https://img.hacpai.com/file/2019/08/image-b72e33da.png)


>命令：cat -A game.txt
显示文件内容的同时，还将显示原来看不见的特殊字符，其中包括换行符。如图：
![image.png](https://img.hacpai.com/file/2019/08/image-db00e00f.png)
可看看到windows下的换行符为 **^M**  ,我们可以在LIINUX新建一个文件，并输入一个回车，然后看一下Linux的换行符是什么样子的。
可以看到是**$**。

>命令：**cat -s**
此命令，可以将文件中两个或多个相邻的空行合并成一个空行。
此处不再演示。

>命令：**cat -b**
此命令，可以显示行号。
![image.png](https://img.hacpai.com/file/2019/08/image-91afd9b9.png)
可以看到空行是不会加的。

除了以上介绍的用法，cat命令可以创建新文件。
>命令：**cat > 文件名**
如图：
![image.png](https://img.hacpai.com/file/2019/08/image-9e9728ed.png)
输入命令以后，再下方输入文字。然后在空行按ctal+D 键，保存。再使用cat键查看一下刚才新建的文件。如图.
![image.png](https://img.hacpai.com/file/2019/08/image-68668825.png)
哈哈，神奇不神奇呢。

>指点迷津
不要使用cat命令浏览二进制文件，不然终端窗口容易停止工作，如果发生了这种情况，可以关闭终端窗口，之后再开启一个新的窗口。
# 4.6head命令。
head命令，默认只显示前10行信息，
>命令:**head 文件名**
如图：
![image.png](https://img.hacpai.com/file/2019/08/image-295dc7f2.png)
可以看到head命令是用换行符计算行数的。空行也算一行。

>命令：**head -n 行数 文件名**
此命令设置显示的行数。
![image.png](https://img.hacpai.com/file/2019/08/image-811b52b9.png)
也可以直接用命令 **head -20 文件名** 同上命令。
# 4.7、tail命令
tail命令与head命令相反，此命令是看最后几行。该命令默认显示后10行的内容。
>**tail 文件名**
![image.png](https://img.hacpai.com/file/2019/08/image-6756128a.png)
默认10行。

>**tail -n**
此命令的意思是从文件末尾算起的第n行。
例如：**tail -2**
![image.png](https://img.hacpai.com/file/2019/08/image-d69ca948.png)
显示后两行。

>**tail -f /var/log/messages**
此命令最最重要的一个选项就是-f了，其含义是当一个正文文件的内容发生变化时，tail命令将把这些变化的信息显示在屏幕上。使用-f或-follow选项非常适合监视日志系统的(log)文件。
例如以上命令监控messages消息文件。![image.png](https://img.hacpai.com/file/2019/08/image-c8aa806c.png)
首先输入命令，然后再开一终端，root用户，然后重启一下网络**(service netword restart)**，此时可以看到系统会一直显示/var/log/messages这个日志文件的变化信息。最后，按Ctrl+c即可退出tail命令。
tail命令在实际中，是经常用到的，用来监控一些日志文件的异常报错信息，方便排查问题。

# 4.8、使用wc命令显示文件行、单词和字符数
**wc -options 文件名**
-l:仅显示行数，l是line的第1个字符。
-w：仅显示单词数，w是word的第1个字符。
-c：仅显示字符数，c是charactger的第1个字符。
>wc 文件名
默认不加选项的话，将显示文件中所包含的行数、单词数和字符数。如图：
![image.png](https://img.hacpai.com/file/2019/08/image-bd5d1007.png)
这里单独选项不再举例。

# 4.9、使用more命令浏览文件。
如果一个文件很大，使用前面linux命令来浏览该文件还是不太方便，能不能让文件中的内容在屏幕上每次只显示一页，在需要时再翻到下一页呢。当然呢，那就是**more命令。** 
>more 文件名
当使用命令时，底部会显示--More--(n%)的信息(其中，n%是已经显示文件内容的百分比)。当输入命令好，可以用键盘上来进行操作。
空格键：向前向下移动一个屏幕。
Enter键：一次移动一行。
b：往回（向上）移动一屏幕。
h：显示一个帮助菜单。
/字符串：向前搜索这个字符串。
n：发现这个字符串的下一次出现。
q：退出more命令并返回操作系统提示符下。
v：在当前启动/usr/bin/vi （vi是Linux或UNIX自带的文字编辑器）

# 4.10、您应该掌握的内容
怎样查看ftp服务的状态？
怎样启动ftp服务？
ftp的两种发送（传输）模式。
怎样利用ftp将一个或多个文件从本地传送到远程系统？
怎样利用ftp将一个或多个文件从远程系统传送到本地？
file命令的用法？
怎样使用cat命令浏览正文文件的内容？
使用cat命令浏览二进制文件可能的后果及解决方法。
怎样使用cat命令来创建文件？
怎样使用head命令浏览文件中的内容？
怎样使用tail命令浏览文件中的内容？
怎样使用tail命令监督系统日志？
使用wc命令。
怎样利用wc命令获取系统上的用户总数？
怎样使用 more命令来浏览文件？
more命令的常用选项的用法。

