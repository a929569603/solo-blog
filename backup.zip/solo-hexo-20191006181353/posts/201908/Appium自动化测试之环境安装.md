title: Appium自动化测试之环境安装
date: '2019-08-22 19:06:45'
updated: '2019-08-22 19:10:37'
tags: [appium, 移动端自动化, python]
permalink: /articles/2019/08/22/1566472004945.html
---
# ﻿安装前准备：
>[Python 安装包下载](https://u16518217.pipipan.com/fs/16518217-238986333)
[Node-v6.11.2下载](https://u16518217.pipipan.com/fs/16518217-238989745)
[安卓SDK下载](https://u16518217.pipipan.com/fs/16518217-238991845)
[appium_forwindows下载](https://u16518217.pipipan.com/fs/16518217-238992257)
-------------------------------------------------------------------
以上四个文件下载下来后，分别解压安装，无特殊要求，下一步->下一步。
# 环境变量添加
以下这些添加到系统变量中的 **path** 变量中。不要说不知道怎么加哦。。。。。。
>**C:\Python27\/**   -----------------python默认安装的话是这儿
C:\XXXXXXX\sdk\tools------------------SDK下载下来看你解压到哪
C:\XXXXXXX\sdk\platform-tools-----------------SDK下载下来看你解压到哪
C:\Program Files (x86)\Appium\node_modules\.bin;----------Appium默认安装的话是这儿
C:\Program Files\nodejs\;------------------Node默认的话是这儿

下面新建系统变量 **ANDROID_HOME** 
>添加**C:\adt-bundle-windows-x86-20130917\sdk**-------SDK目录。看你解压到哪。。。。。。。



# 手机驱动的安装
>[手机USB驱动下载](https://u16518217.pipipan.com/fs/16518217-238996847)
有些同学第一次安装后，手机无法连接电脑，adb devices显示不出来手机型号。所以要安装一下手机驱动。
**手机驱动安装：**
1.首先下载，我上传的附件。
![](http://upload-images.jianshu.io/upload_images/10034856-e1154df7c457e9f1.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
2.数据线插入手机连接电脑，点击计算机右键-属性-设备管理器。
![](http://upload-images.jianshu.io/upload_images/10034856-7e189666368995f2.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
        找到以上选项 Android Composite ADB Interface 右击选择-更新驱动程序软件。如下图
![](http://upload-images.jianshu.io/upload_images/10034856-73f11b1513ea5a26.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
点击浏览计算机查找驱动程序软件。手动选择解压后的驱动文件夹下一步安装。（我电脑安装过了，再此不再放图，选择文件夹后，下一步下一步安装就行。）
3.再到**C:\Users\Administrator\.android** 文件夹新建一个**adb_usb.ini**文件，里面加入手机硬件ID。（我这边是两个手机的ID。）如下图
![](http://upload-images.jianshu.io/upload_images/10034856-e073d7182cd12bb2.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
4.手机ID在哪看？ 在您刚才安装的驱动位置，设备管理--Android Composite ADB Interface 右击属性--详细信息--选择**硬件ID**，下面信息VID_ 后面就是此手机ID我的手机是 2C73  把此加入到第三步的adb_usb.ini中。必须加0X。
![](http://upload-images.jianshu.io/upload_images/10034856-e2d3c6e5631a6613.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
5.一切OK后，重新插拔手机，再次CMD试一下adb devices。是不是OK啦？
![](http://upload-images.jianshu.io/upload_images/10034856-31e44a2da67bc388.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

注意：以上到此，环境基本安装成功，不出意外，可以连接真机进行自动化测试。
但是目前安卓版本大多为7.1或更高了，APPIUM这就会出现无法连接7.1系统的问题，这里给大家放上文件大家直接下载，下载后覆盖或移动到**C:\Program Files (x86)\Appium\node_modules\appium\lib**
[adb.js下载](https://u16518217.pipipan.com/fs/16518217-239033094)

好了此教程到此结束。如有问题请留言。看到会第一时间回复。

后面会讲解如果连接真机。如何在真机上进行一系列操作。请持续关注我的文章。谢谢各位。
