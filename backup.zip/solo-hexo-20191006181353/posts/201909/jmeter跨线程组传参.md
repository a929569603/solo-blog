title: jmeter跨线程组传参
date: '2019-09-09 19:33:04'
updated: '2019-09-09 19:33:59'
tags: [jmeter]
permalink: /articles/2019/09/09/1568028784034.html
---
# 传递顺序：   线程组1的值${aa} 需要传给线程组2使用。
## 需要使用的函数：
> **__setProperty(aa,${aa},)**
使用方法，在线程组1中，参数的逻辑块上添加BeanShell Sampler
![image.png](https://img.hacpai.com/file/2019/09/image-c03a0cdf.png)


-------------------------------
## 调用方法:
>调用方法
**${__property(aa)}**
![image.png](https://img.hacpai.com/file/2019/09/image-15a8a18e.png)


好了去试下结果吧。

注意：多线程并发时，假如传的参数不一致，会出错的，只会使用最后一个值。
例如：三个用户并发登录，在登录时获取token， 只会保存第三个用户的token值，传给第二线程组使用，第二线程组所有线程都会用第三个人的token，会出错的。

### 跨线程组传参，只适用于传递的参数是个定值。
